-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: allkennesaw
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `marrietacampus`
--

DROP TABLE IF EXISTS `marrietacampus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marrietacampus` (
  `id_C` int NOT NULL,
  `Location_Name_C` varchar(45) NOT NULL,
  `Longitude_C` double NOT NULL,
  `Latitude_C` double NOT NULL,
  `Descriptions_C` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_C`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marrietacampus`
--

LOCK TABLES `marrietacampus` WRITE;
/*!40000 ALTER TABLE `marrietacampus` DISABLE KEYS */;
INSERT INTO `marrietacampus` VALUES (1,'The Globe',33.94009,-84.51998,'donated to KSU for housing Olympic athletes'),(2,'The Rock',33.93917,-84.52106,'painted and slapped during social events. '),(3,'KSU Sign @ H. Village',33.93676,-84.5211,'a background for pictures.'),(4,'KSU Sign @ S. Center',33.94023,-84.51971,'in front of the Joe Mack Student Center.'),(5,'Sycamore Grove ',33.93959,-84.52042,'a common event space.'),(6,'Legacy Walk',33.93765,-84.52123,'respectul of SPSU alumni. '),(7,'The Market',33.93874,-84.51801,'Waiting for renovations');
/*!40000 ALTER TABLE `marrietacampus` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-04 19:58:11
