var express = require("express");
var app = express();

var mysql = require("mysql");
var bodyParser = require("body-parser");

const fs = require('fs');



// app.use(bodyParser.json({type:'application/json'}));
// app.use(bodyParser.urlencoded({extended:true}));    //not needed

//creates the connection
var con = mysql.createConnection({
  host: "", //Refers to IP address
  user: "", //Refers to The User of MYSQL
  password: "",
  database: "allkennesaw", //Name of the SQUEMA

});

con.connect(function (error) {
  //To show on the terminal if the connection was successful
  if (error) console.log(error);
  else console.log("connected");
});

//BothCampusesData will be used to create the URL of this connection
app.get("/BothCampusesData", function (req, res) {//BothCampusesData can be any name 
  con.query(
    "SELECT * FROM allkennesaw.marrietacampus", //This SQL STATEMENT decides what data is pulled for the database
    function (error, rows, fields) {
      if (error) console.log(error);
      else {
        res.send(rows);
        

        /*
Code use for debugging
      // let locationlist = [rows]; //testing out data types
      //    let String = rows;
      // let others = "" + String;
      // console.log(rows);
      //  const markerinfo =[];
      //  for( let i =0; i<5; i++)
      //  {
      //    markerinfo.push(
      //        {
      //          latitude:   rows[i].latitude,
      //          longitude:  rows[i].longitude,
      //          id:i,
      //        }
      //    );
      //  }
      //locationlist[1] = locationlist[0].split(",");
      // console.log(JSON.stringify(others.split(",")));
      //  console.log('THE VALUES ARE', rows[0].Longitude);
      // locationlist[1] = locationlist[0].split(",");

       */
      }
      console.log("somebody connected");
      const content = JSON.stringify(rows);
        console.log(content);
        //write the database into a given file type and folder location
        fs.writeFile('', content, err=> {
          if(err){
            console.error(err);
          }
        });

    }
  );
});




var server = app.listen(3000, function () {
  //works without these variables
  // var host = server.address().address
  // var port = server.address().port

  //Tests the connection and shows a clickable url to see database data
  console.log("start");
  console.log(
    "Go to http://localhost:3000/BothCampusesData so you can see the data."
  ); //make sure BothCampusesData matches in the initial app.get("")
  //  console.log(rows); //debugging purposes
  
 

});
//.fetch ('http://localhost:3000/BothCampusesData');




//reference codes
//https://github.com/Hardeepcoder/mysql-in-react-native-with-express-nodejs-server
//https://stackoverflow.com/questions/58638651/react-native-and-mysql-connection
//https://www.arubacloud.com/tutorial/how-to-use-nodejs-to-copy-files-via-scp.aspx