import React, { Component, useState, useEffect} from "react";
import {
  Button,
  View,
  Text,
  StyleSheet,
  Dimensions,
  TextInput,
  SafeAreaView,
  Image ,
} from "react-native";

const Dynamicpage = ({ route }) => {
 
  const imageUrl = route.params.imageParams;
//console.log(imageUrl); //used for debugging
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <View style={styles.container}>
        <Text style={styles.heading}>{route.params.paramT}</Text>
        <Image source={{uri: imageUrl}} style={styles.image} />
        <Text style={styles.textStyle}>
          {route.params.paramT} is known for being {route.params.paramF} 
        </Text>
      </View>
    </SafeAreaView>
  );
};

export default Dynamicpage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    padding: 20,
    backgroundColor: "#f2e9c4",
    height: 1200,
  },
  heading: {
    fontSize: 25,
    textAlign: "center",
    marginVertical: 10,
    padding: 3,
    backgroundColor: "goldenrod",
    height:50,
    width: 400,
    borderWidth: 5,
    fontWeight: "700",
  },
  textStyle: {
    textAlign: "center",
    fontSize: 16,
    padding: 15,
    backgroundColor: "goldenrod",
    marginVertical: 10,
    height: 290,
    width: 400,
    borderColor: "goldenrod",
    borderWidth: 10,
  },
  image: {
    height: 400,
    width: 400,

    borderColor: "goldenrod",
    borderWidth: 5,
  },
});

//references
// www.aboutreact.com
