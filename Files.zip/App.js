import { StatusBar } from "expo-status-bar";
import React, { Component, useState, useEffect } from "react";
import { Linking } from 'react-native';
import {
  Button,
  View,
  Text,
  StyleSheet,
  Dimensions,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  TouchableOpacity,
} from "react-native";
import { NavigationContainer, useNavigation } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import firebase from "firebase/compat";
import { initializeApp } from "firebase/app";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from "firebase/auth";

//All the other screens
import Kennesaw from "./Kennesaw";
import Marietta from "./Marietta";
import Dynamicpage from "./dynamicPage";
//import SignedInHome from "./SignedInHome";
 //import Login from "./LoginScreen";
import { NativeScreenNavigationContainer } from "react-native-screens";

const Stack = createNativeStackNavigator();

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDT26npXaUvOpxEAZ4MiLRbAO-_yn8U49I",
  authDomain: "fir-auth-a1a0f.firebaseapp.com",
  projectId: "fir-auth-a1a0f",
  storageBucket: "fir-auth-a1a0f.appspot.com",
  messagingSenderId: "176205862420",
  appId: "1:176205862420:web:29e7ab9ce894e0fc4cb901",
};
// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and get a reference to the service
const auth = getAuth(app);

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Marietta" component={Marietta} />
        <Stack.Screen name="Kennesaw" component={Kennesaw} />
        <Stack.Screen name="Dynamicpage" component={Dynamicpage} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="SignedInHome" component={SignedInHome} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}



function Login(){
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const navigations = useNavigation();

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) {
        navigations.replace("SignedInHome");
      }
    });

    return unsubscribe;
  }, []);

  const handleSignUp = () => {
    createUserWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        const user = userCredential.user;
        console.log(user, email);
      })
      .catch((error) => alert(error.message));
  };

  const handleSignIn = () => {
    signInWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        const user = userCredential.user;
        //     const user = userCredentials.user;
        console.log(user, email);
      })
      .catch((error) => alert(error.message));
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior="padding">
      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Email"
          value={email}
          onChangeText={(text) => setEmail(text)}
          style={styles.input}
        />
        <TextInput
          placeholder="Password"
          value={password}
          onChangeText={(text) => setPassword(text)}
          style={styles.input}
          secureTextEntry
        />
      </View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity onPress={handleSignIn} style={styles.button}>
          <Text styles={styles.button}>Login</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={handleSignUp} style={styles.button}>
          <Text styles={styles.button}>Register</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};



class HomeScreen extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <Text>Home Screen</Text>
        <Button
          title="Marietta Campus"
          onPress={() => this.props.navigation.navigate("Marietta")}
        />
        <Button
          title="Kennesaw Campus "
          onPress={() => this.props.navigation.navigate("Kennesaw")}
        />
        <Button
          title="Login"
          onPress={() => this.props.navigation.navigate("Login")}
        />
      </View>
    );
  }
}







function SignedInHome() {
  const navigation = useNavigation();

  const handleSignOut = () => {
    auth
      .signOut()
      .then(() => {
        navigation.replace("Login");
      })
      .catch((error) => alert(error.message));
  };

  return (
    <View style={styles.container}>
      <Text>Welcome, {auth.currentUser?.email}!</Text>

      <Button
        title="Marietta Campus"
        onPress={() => navigation.navigate("Marietta")}
      />
      <Button
        title="Kennesaw Campus "
        onPress={() => navigation.navigate("Kennesaw")}
      />
      <Button 
        title="Request Landmark" 
        onPress={() => Linking.openURL("https://forms.gle/4mVXYjUHDhD7dc4T6")}
      />

      <TouchableOpacity onPress={handleSignOut} style={styles.button}>
        <Text style={styles.buttonText}>Sign out</Text>
      </TouchableOpacity>
    </View>
  );
};




const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f2e9c4",
    alignItems: "center",
    justifyContent: "center",
  },
  inputContainer: {
    width: "80%",
  },
  input: {
    backgroundColor: "white",
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 10,
    marginTop: 5,
  },
  buttonContainer: {
    width: "60%",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 40,
  },
  button: {
    backgroundColor: "goldenrod",
    borderColor: "black",
    borderWidth: 2,
    width: "80%",
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
  },
  buttonOutline: {
    backgroundColor: "white",
    marginTop: 5,
    borderColor: "##52471a",
    borderWidth: 2,
  },
  buttonText: {
    color: "#52471a",
    fontWeight: "700",
    fontSize: 16,
  },
  buttonOutlineText: {
    color: "##52471a",
    fontWeight: "700",
    fontSize: 16,
  },
});
