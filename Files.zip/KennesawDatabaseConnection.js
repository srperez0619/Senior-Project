var express = require("express");
var app = express();

var mysql = require("mysql");
var bodyParser = require("body-parser");

// app.use(bodyParser.json({type:'application/json'}));
// app.use(bodyParser.urlencoded({extended:true}));    //not needed

//creates the connection
var con = mysql.createConnection({
  host: "localhost", //Refers to IP address
  user: "root", //Refers to The User of MYSQL
  password: "F2ikvQ7-m2p2",
  database: "allkennesaw", //Name of the SQUEMA
  //F2ikvQ7-m2p2
  //Killer12-14Gq
});

con.connect(function (error) {
  //To show on the terminal if the connection was successful
  if (error) console.log(error);
  else console.log("connected");
});

//BothCampusesData will be used to create the URL of this connection
app.get("/BothCampusesData", function (req, res) {//BothCampusesData can be any name 
  con.query(
    "SELECT * FROM allkennesaw.marrietacampus LEFT JOIN allkennesaw.kennesawcampus on marrietacampus.id_C = kennesawcampus.id", //This SQL STATEMENT decides what data is pulled for the database
    function (error, rows, fields) {
      if (error) console.log(error);
      else {
        res.send(rows);

        /*
Code use for debugging
      // let locationlist = [rows]; //testing out data types
      //    let String = rows;
      // let others = "" + String;
      // console.log(rows);
      //  const markerinfo =[];
      //  for( let i =0; i<5; i++)
      //  {
      //    markerinfo.push(
      //        {
      //          latitude:   rows[i].latitude,
      //          longitude:  rows[i].longitude,
      //          id:i,
      //        }
      //    );
      //  }
      //locationlist[1] = locationlist[0].split(",");
      // console.log(JSON.stringify(others.split(",")));
      //  console.log('THE VALUES ARE', rows[0].Longitude);
      // locationlist[1] = locationlist[0].split(",");

       */
      }
    }
  );
});
var server = app.listen(3000, function () {
  //works without these variables
  // var host = server.address().address
  // var port = server.address().port

  //Tests the connection and shows a clickable url to see database data
  console.log("start");
  console.log(
    "Go to http://localhost:3000/BothCampusesData so you can see the data."
  
    ); //make sure BothCampusesData matches in the initial app.get("")

}
);

//reference codes
//https://github.com/Hardeepcoder/mysql-in-react-native-with-express-nodejs-server
//https://stackoverflow.com/questions/58638651/react-native-and-mysql-connection
