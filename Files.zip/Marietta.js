import React, { Component, useState, useEffect } from "react";
import {
  Button,
  View,
  Text,
  StyleSheet,
  Dimensions,
  TextInput,
} from "react-native";

import MapView, { Callout } from "react-native-maps";
import { Marker } from "react-native-maps";


//Value declarations
const { width, height } = Dimensions.get("window");
const ASPECT_RATIO = width / height;
const LATITUDE_DELTA = 0.01;
//remove this fo security
fetch("insert database url") // Fetches data from a running database 
  .then((response) => response.json()) //
  .then((users) => (coordinateListM = users)); //put the sql query into the array coordinateListM
  

  
export default class Marietta extends React.Component {
  constructor(props) {
    super(props);
    console.log(coordinateListM[0].Descriptions_C);
    console.log(coordinateListM[0].Location_Name_C);
    var ImageUrL = "insert database url/Senior/Marietta_Images/"; //All images for Marietta are in this folder location
    const markerinfo = []; //Saves the values from coordinateListM into an array for google maps markers
    for (let i = 0; i < coordinateListM.length; i++) {
      markerinfo.push({
        latitude: coordinateListM[i].Longitude_C, //coordinateListM must have capital Latitude
        longitude: coordinateListM[i].Latitude_C, //coordinateListM must have capital Longitude
        id: i,
        title: coordinateListM[i].Location_Name_C,
        Description: coordinateListM[i].Descriptions_C,
        ImagesLocation: ImageUrL.concat(i+1 , ".HEIC"), //each photo is named based on the id of the image, this only allows for one image at the moment

      });
    }

    this.state = {
      markerinfo,
    };
    console.log(coordinateListM[1].Latitude_C); //debug purposes
    console.log(markerinfo); // prints values of markerinfo, debug purposes
  }

  render() {
    const markers = this.state.markerinfo.map((markerinfo) => (
      <Marker
        coordinate={markerinfo}
        key={markerinfo.id}
        title={markerinfo.title}
        onCalloutPress={() =>
          this.props.navigation.navigate("Dynamicpage", {
            paramT: markerinfo.title,
            paramF: markerinfo.Description,
            imageParams: markerinfo.ImagesLocation,
          })
        }
        // onPress={() => this.props.navigation.goBack()}
      />
    ));

    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
        <Text>Marietta Campus</Text>
        <View style={styles.container}>
          <MapView
            initialRegion={{
              //Initial location where google maps will start at
              latitude: 33.94,
              longitude: -84.52,
              latitudeDelta: 0.01,
              longitudeDelta: LATITUDE_DELTA * ASPECT_RATIO,
            }}
            ref={(ref) => {
              this.map = ref;
            }}
            style={styles.map}
          >
            {/* creates markers from the markers variables */}
            {markers}

            {/* //Marker with changed attributes like clickable button */}
          </MapView>
        </View>

        {/* //Buttons to change screen  */}

        <Button
          title="Change to Kennesaw Map"
          onPress={() => this.props.navigation.navigate("Kennesaw")}
        />
      </View>
    );
  }
}

//Style and formatting of the page
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  text: {
    color: "black",
  },
  map: {
    width: Dimensions.get("window").width,
    height: Dimensions.get("window").height,
  },
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
});
//reference to combine text https://reactnativecode.com/combine-two-strings/